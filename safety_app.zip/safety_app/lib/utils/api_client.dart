import 'package:get_storage/get_storage.dart';

class ApiClient {
  static final gs = GetStorage();
}

const String imgUrl = 'http://192.168.1.72/Kumar/KumarProperties/storage/';
