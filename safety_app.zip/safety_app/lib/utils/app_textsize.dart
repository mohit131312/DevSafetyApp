class AppTextSize {
  static const double textSizeExtraSmall = 12.0;
  static const double textSizeSmalle = 13.0;

  static const double textSizeSmall = 14.0;
  static const double textSizeSmallm = 15.0;

  static const double textSizeMedium = 16.0;
  static const double textSizeMediumm = 17.0;

  static const double textSizeLarge = 20.0;
  static const double textSizeExtraLarge = 24.0;
}
