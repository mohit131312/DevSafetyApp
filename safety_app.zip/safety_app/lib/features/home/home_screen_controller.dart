import 'package:get/get.dart';

class HomeScreenController extends GetxController {}
