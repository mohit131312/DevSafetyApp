








//                     import 'dart:io';
// import 'dart:typed_data';

// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:signature/signature.dart';

// class LabourUndertakingController extends GetxController {
  

//   @override
//   void onInit() {
//     super.onInit();
//  showDialog(
//                         context: context,
//                         barrierDismissible: false,
//                         builder: (BuildContext context) =>
//                             CustomLoadingPopup());
//                     await labourPreviewController.safetySaveLabour(
//                         context, categoryId);
//                     Get.back();
//   }

  
 
  
// }
